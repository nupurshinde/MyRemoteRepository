var x = require('readline');
var prompts = x.createInterface(process.stdin, process.stdout);
prompts.question("Enter no of Rows", function(n)
{
var i,j;
var a,b;
var str="";
for(i= (-n);i<= n;i++)
            {
                for(j =(-n);j<= n;j++)
                {
			if(i<0)
				a=i*(-1);
			else
				a=i;
			
			if(j<0)
				b=j*(-1);
			else
				b=j;
			
                    if (a+b <= n)
                        str=str+"*";
                    else
                        str=str+" ";

                }
                console.log(str);
		str="";
            }
});
