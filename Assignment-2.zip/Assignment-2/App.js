var app = angular.module("myApp", []);

app.controller('RepeatCon1',function($scope) {
    $scope.names = [
         {name:'Nupur',age:23},
         {name:'Gaurav',age:26},
         {name:'Seema',age:30},
		 {name:'Ganesh',age:55}
    ];
	
});

