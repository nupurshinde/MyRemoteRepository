
var readline = require('readline');
var rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

var MongoClient = require('mongodb').MongoClient;
var dbHost = 'mongodb://localhost/MongoData1';
var myTable = "emp";
var con;

var stuInsert = function(err, data){
  if(err) throw err;
  console.log("emp data inserted successfully");
  showMenu(con);
}

var stuUpdate = function(err, data){
  if(err) throw err;
  console.log("emp data updated successfully");
  showMenu(con);
}
var studelete = function(err, data){
  if(err) throw err;
  console.log("emp data deleted successfully");
  showMenu(con);
}
var showMenu = function(db){
  console.log("Welcome User which operation you want to perform for emp");
  console.log("1. Add");
  console.log("2. Display");
  console.log("3. Update");
  console.log("4. Delete");
  console.log("5. Quit");
  rl.question("Enter your choice: ", function(answer){
    console.log("Choice entered is: " + answer);
    switch(answer){
      case "1":
        insertData(con);
        break;
      case "2":
        show(con);
        break;
      case "3":
        update1(con);
        break;
      case "4":
        deleteStu(con);
        break;
      case "5":
        console.log("Press Ctrl+C to exit the program");
        return;
    }

  })
}

var insertData = function(db){
  rl.question("Enter the name of the emp: ", function(stuName){
     rl.question("Enter id of emp: ", function(id){
       rl.question("Enter city of emp ", function(city){
           
                 db.collection(myTable).insert({
                    'name':stuName,
                    'id': id,
                    'city': city
                  }, stuInsert);
               });
             }
           );
         });
      }


var show = function(db){
  db.collection(myTable).find({},{},{}).toArray(
    function(err, entry){
      for(index in entry){
        console.log(entry[index]);
      }
      showMenu(con);
    }
  );
}

var update1 = function(db){
  rl.question("Enter id of emp of which data you want to update: ", function(answer){

    db.collection(myTable).find({id: answer},{},{}).toArray(
      function(err, docs){
          rl.question("Enter the new name of the emp : ", function(stuName){
               rl.question("Enter the new city of emp", function(city){
                 
                         db.collection(myTable).update({"id":answer}, {
                            'name':stuName,
                            'city': city,
                            'id':answer
                          }, stuUpdate);
                 });
               });
          });
        });
      }



var deleteStu = function(db){
  rl.question("Enter id of emp you want to delete: ", function(answer){
    db.collection(myTable).find({id: answer},{},{}).toArray(
      function(err, entry){
        
          db.collection(myTable).remove({"id":answer}, studelete);
        
      });
  });
}

MongoClient.connect(dbHost, function(err, db){
  if ( err ) throw err;
  con = db;
  showMenu();
});