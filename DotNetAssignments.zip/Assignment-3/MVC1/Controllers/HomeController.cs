﻿using MVC1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC1.Controllers
{
    public class HomeController : Controller
    {



        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "This is my simple MVC application.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "You can contact me at : ";

            return View();
        }
        public ActionResult UserProfile()
        {
            return View();
        }
        public ActionResult Cleare()
        {
            return View("UserProfile");
        }
        public ActionResult Test()
        {
            User u1 = new User();
            u1.id = Convert.ToInt32( Request.Form["id"]);
            u1.name=Request.Form["name"];   
            return View(u1);
        }
    }
}