﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC1.Models
{
    public class User
    {
        public int id { get; set; }
        public string name { get; set; }
        public string addr { get; set; }
        public int age { get; set; }
        public long contact { get; set; }
    }
}