﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PascalTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.Write("Enter the number of rows: ");
            string s = Console.ReadLine();
            bool isNum = Int32.TryParse(s, out num);

            if (isNum)
            {
                int n = Convert.ToInt32(s);

                for (int y = 0; y < n; y++)
                {
                    int c = 1;
                    for (int q = 0; q < n - y; q++)
                    {
                        Console.Write("  ");
                    }

                    for (int x = 0; x <= y; x++)
                    {
                        if(c<=9)
                            Console.Write("   " + c);
                        else
                            Console.Write("  " + c);
                        c = c * (y - x) / (x + 1);
                    }
                    Console.WriteLine();
                    Console.WriteLine();
                }
            }
            else
            {
                Console.Write("plz enter number.");
            }
             
               
            Console.ReadLine();
            }
        }
    }












