﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRUD00
{
    public partial class home : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"data source=MWP37\SQLEXPRESS;database=Data1; integrated security=SSPI");

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("record inserted");
        }

        //string str = "select * from emp where ID={0}";
        //string query = string.Format(str, Convert.ToInt32(TextBox1.Text));
        //SqlCommand cmd = new SqlCommand(query, con);
        //con.Open();
        //SqlDataReader reader = cmd.ExecuteReader();
        //while (reader.Read())
        //{
        //    TextBox1.Text = reader[0].ToString();
        //    TextBox2.Text = reader[1].ToString();
        //    TextBox3.Text = reader[2].ToString();
        //}
        //con.Close();
    

        protected void Button2_Click(object sender, EventArgs e)
        {
            string str = "insert into emp values({0},'{1}',{2})";
            string query = string.Format(str, Convert.ToInt32(TextBox1.Text), TextBox2.Text, Convert.ToInt32(TextBox3.Text));
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result != 0)
            {
                Console.WriteLine("record inserted");
            }
            else
                Console.WriteLine("some problem in insertion");
            con.Close();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string str = "update emp set name='{1}',salary={2} where ID={0}";
            string query = string.Format(str, Convert.ToInt32(TextBox1.Text), TextBox2.Text, Convert.ToInt32(TextBox3.Text));
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result != 0)
            {
                Console.WriteLine("record updated");
            }
            else
                Console.WriteLine("some problem in updating record");
            con.Close();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            string str = "delete from emp where ID={0}";
            string query = string.Format(str, Convert.ToInt32(TextBox1.Text));
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result != 0)
            {
                Console.WriteLine("record deleted");
            }
            else
                Console.WriteLine("some problem in deletion");
            con.Close();

        }
    }
}