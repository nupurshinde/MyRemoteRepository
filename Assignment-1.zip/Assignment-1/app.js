var app1 = angular.module("myApp1", []);
app1.controller("con1", function($scope) {
    $scope.var1 = "Nupur";
    $scope.var2 = "nupur@gmail.com";
});
app1.controller('con2', function($scope) {
   $scope.var1 = "Nupur";
    $scope.var2 = "Shinde";
    $scope.var3= function() {
        return $scope.var1 + " " + $scope.var2;
    };
});