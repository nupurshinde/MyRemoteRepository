var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
  res.render('index', { title: 'Employee Info' });
});

router.post('/',function(req,res){
	var db=req.db;
	var eId=req.body.id;
	var eName=req.body.name;
	var eSalary=req.body.salary;
	var coll=db.get('emp');
	coll.insert({"id":eId,"name":eName,"Salary":eSalary},function(err,doc){
		if(err){res.send("data is not inserted")}
		else{res.redirect("/")}
		});	
});

 


module.exports = router;
