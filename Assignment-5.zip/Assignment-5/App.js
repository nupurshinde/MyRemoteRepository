
    var myApp = angular.module('myApp', ['ngRoute']);

    
    myApp.config(function($routeProvider) {
        $routeProvider

            .when('/', {
                templateUrl : 'home.html',
                controller  : 'mainController'
            })

          
            .when('/about', {
                templateUrl : 'about.html',
                controller  : 'aboutController'
            })

       
            .when('/contact', {
                templateUrl : 'contact.html',
                controller  : 'contactController'
            })

		��.otherwise({
������������redirectTo:�'home.html'
��������});
    });

   
    myApp.controller('mainController', function($scope) {
        $scope.message = 'Hello this is HOME page';
    });

    myApp.controller('aboutController', function($scope) {
        $scope.message = 'This is about page';
    });

    myApp.controller('contactController', function($scope) {
        $scope.message = 'This is contact page';
    });