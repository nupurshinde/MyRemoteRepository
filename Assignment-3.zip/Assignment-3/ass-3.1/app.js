var app = angular.module("myApp", []);
app.directive("hello", function() {
    return {
	 restrict : "EA",
        template : "<h1>Custom Directive Hello World</h1>"
    };
});