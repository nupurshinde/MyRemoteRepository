var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
// This responds a POST request
router.post('/', function (req, res) {
	name=req.body.name;
	 email=req.body.email;
	 res.render('index', { name,email });
});

// This responds a DELETE request 
router.delete('/', function (req, res) {
  name=req.body.name;
  userList=req.body;
  userList.splice(name,1);
  res.render('index',{userList});
});

module.exports = router;
