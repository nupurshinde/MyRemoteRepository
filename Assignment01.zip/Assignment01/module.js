var app = angular.module("HomeApp", []);
app.controller("StudentsController", function($scope) {

    $scope.students = [
        {
        "name": "Nupur",
        "class1":"BE",
        "marks": 80
        },
        {
        "name": "Seema",
        "class1":"BSC",
        "marks": 70
        },
         {
        "name": "Pooja",
        "class1":"BBA",
        "marks": 75
        }
    ];
$scope.putRow=function()
{
	$scope.students.push({'name':$scope.name,'class1':$scope.class1,'marks':$scope.marks});
	$scope.name='';
	$scope.class1='';
	$scope.marks='';
};


$scope.removeRow = function(name){				
		var index = -1;		
		var comArr = eval( $scope.students );
		for( var i = 0; i < comArr.length; i++ ) {
			if( comArr[i].name === name ) {
				index = i;
				break;
			}
		}
		if( index === -1 ) {
			alert( "Something gone wrong" );
		}
		$scope.students.splice( index, 1 );		
	};



});